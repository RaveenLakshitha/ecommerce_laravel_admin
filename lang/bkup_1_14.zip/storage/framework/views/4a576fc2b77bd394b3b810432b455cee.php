

<?php $__env->startSection('title', __('file.appointment_number') . $appointment->id . ' - ' . ($appointment->patient?->full_name ?? __('file.unknown'))); ?>

<?php $__env->startSection('content'); ?>
<div class="px-4 sm:px-6 lg:px-4 pb-4 sm:py-12 pt-20">

    <div class="flex items-center text-sm text-gray-500 dark:text-gray-400 mb-4">
        <a href="<?php echo e(route('appointments.index')); ?>" class="hover:text-indigo-600 dark:hover:text-indigo-400 transition">
            <?php echo e(__('file.appointments')); ?>

        </a>
        <svg class="w-4 h-4 mx-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
        </svg>
        <span class="font-medium text-gray-900 dark:text-white">
            #<?php echo e($appointment->id); ?> • <?php echo e(Str::limit($appointment->patient?->full_name ?? '—', 28)); ?>

        </span>
    </div>

    <div class="mb-6">
        <div class="flex items-center justify-between">
            <div>
                <h1 class="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                    <?php echo e(__('file.appointment_number')); ?><?php echo e($appointment->id); ?>

                </h1>
                <div class="flex gap-2">
                    <span class="px-2 py-1 text-xs font-medium rounded
                        <?php switch($appointment->status):
                            case ('pending'): ?>    bg-amber-100 text-amber-700 <?php break; ?>
                            <?php case ('approved'): ?>   bg-green-100 text-green-700 <?php break; ?>
                            <?php case ('confirmed'): ?>  bg-blue-100 text-blue-700 <?php break; ?>
                            <?php case ('completed'): ?>  bg-emerald-100 text-emerald-700 <?php break; ?>
                            <?php case ('cancelled'): ?>  bg-red-100 text-red-700 <?php break; ?>
                            <?php case ('rejected'): ?>   bg-gray-100 text-gray-700 <?php break; ?>
                            <?php default: ?>            bg-gray-100 text-gray-600
                        <?php endswitch; ?>">
                        <?php echo e(ucfirst(__("file.{$appointment->status}"))); ?>

                    </span>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($appointment->appointment_type): ?>
                        <span class="px-2 py-1 text-xs font-medium rounded bg-violet-100 text-violet-700">
                            <?php echo e(ucwords(str_replace('_', ' ', $appointment->appointment_type))); ?>

                        </span>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>

            <div class="flex gap-2">
                <a href="<?php echo e(route('appointments.edit', $appointment)); ?>"
                   class="px-4 py-2 bg-gray-800 text-white text-sm rounded hover:bg-gray-900">
                    <?php echo e(__('file.edit')); ?>

                </a>
                <form method="POST" action="<?php echo e(route('appointments.destroy', $appointment)); ?>" class="inline">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button type="submit" onclick="return confirm('<?php echo e(__('file.delete_confirm')); ?>')"
                            class="px-4 py-2 bg-red-600 text-white text-sm rounded hover:bg-red-700">
                        <?php echo e(__('file.delete')); ?>

                    </button>
                </form>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        <div class="bg-white dark:bg-gray-800 p-4 rounded">
            <h3 class="text-sm font-semibold text-gray-500 dark:text-gray-400 mb-3"><?php echo e(__('file.patient')); ?></h3>
            <a href="<?php echo e(route('patients.show', $appointment->patient)); ?>"
               class="text-base font-medium text-gray-900 dark:text-white hover:text-indigo-600">
                <?php echo e($appointment->patient?->full_name ?? '—'); ?>

            </a>
            <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">
                MRN: <?php echo e($appointment->patient?->medical_record_number ?? '—'); ?>

            </p>
        </div>

        <div class="bg-white dark:bg-gray-800 p-4 rounded">
            <h3 class="text-sm font-semibold text-gray-500 dark:text-gray-400 mb-3"><?php echo e(__('file.doctor')); ?></h3>
            <p class="text-base font-medium text-gray-900 dark:text-white">
                <?php echo e($appointment->doctor ? 'Dr. ' . $appointment->doctor->getFullNameAttribute() : __('file.not_assigned')); ?>

            </p>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($appointment->doctor?->primarySpecialization?->name): ?>
                <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    <?php echo e(ucwords(str_replace('_', ' ', $appointment->doctor->primarySpecialization->name))); ?>

                </p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        <div class="bg-white dark:bg-gray-800 p-4 rounded">
            <h3 class="text-sm font-semibold text-gray-500 dark:text-gray-400 mb-3"><?php echo e(__('file.schedule')); ?></h3>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($appointment->scheduled_start): ?>
                <p class="text-base font-medium text-gray-900 dark:text-white">
                    <?php echo e($appointment->scheduled_start->format('M j, Y')); ?>

                </p>
                <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    <?php echo e($appointment->scheduled_start->format('g:i A')); ?> - <?php echo e($appointment->scheduled_end->format('g:i A')); ?>

                </p>
            <?php else: ?>
                <p class="text-sm text-gray-500 dark:text-gray-400 italic"><?php echo e(__('file.not_scheduled_yet')); ?></p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>

    <div class="bg-white dark:bg-gray-800 p-4 rounded mb-4">
        <h3 class="text-sm font-semibold text-gray-500 dark:text-gray-400 mb-3"><?php echo e(__('file.appointment_details')); ?></h3>
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
                <p class="text-xs text-gray-500 dark:text-gray-400"><?php echo e(__('file.type')); ?></p>
                <p class="text-sm text-gray-900 dark:text-white mt-1">
                    <?php echo e($appointment->appointment_type ? ucwords(str_replace('_', ' ', $appointment->appointment_type)) : '—'); ?>

                </p>
            </div>
            <div>
                <p class="text-xs text-gray-500 dark:text-gray-400"><?php echo e(__('file.duration')); ?></p>
                <p class="text-sm text-gray-900 dark:text-white mt-1">
                    <?php echo e($appointment->duration_minutes ? $appointment->duration_minutes . ' ' . __('file.min') : '—'); ?>

                </p>
            </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($appointment->appointment_type === \App\Models\Appointment::TYPE_ANY && $appointment->specialization): ?>
            <div>
                <p class="text-xs text-gray-500 dark:text-gray-400"><?php echo e(__('file.specialization')); ?></p>
                <p class="text-sm text-gray-900 dark:text-white mt-1">
                    <?php echo e($appointment->specialization->name); ?>

                </p>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <div class="col-span-2 md:col-span-1">
                <p class="text-xs text-gray-500 dark:text-gray-400"><?php echo e(__('file.reason')); ?></p>
                <p class="text-sm text-gray-900 dark:text-white mt-1">
                    <?php echo e($appointment->reason_for_visit ?? '—'); ?>

                </p>
            </div>
        </div>
    </div>

    <div class="bg-white dark:bg-gray-800 p-5 rounded-lg shadow-sm mb-6">
        <div class="flex items-center justify-between mb-4">
            <h3 class="text-sm font-semibold text-gray-600 dark:text-gray-300 uppercase tracking-wide">
                <?php echo e(__('file.treatments')); ?>

            </h3>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(in_array($appointment->status, ['pending', 'approved'])): ?>
                <button type="button" onclick="document.getElementById('treatmentsModal').classList.remove('hidden')"
                        class="text-sm text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-300 font-medium flex items-center gap-1">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                    </svg>
                    <?php echo e(__('file.select_treatments')); ?>

                </button>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$appointment->relationLoaded('treatments') || $appointment->treatments === null || $appointment->treatments->isEmpty()): ?>
            <div class="text-center py-6 text-gray-500 dark:text-gray-400 italic">
                <?php echo e(__('file.no_treatments_added_yet')); ?>

            </div>
        <?php else: ?>
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                    <thead>
                        <tr class="bg-gray-50 dark:bg-gray-800/50">
                            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                                <?php echo e(__('file.treatment')); ?>

                            </th>
                            <th class="px-4 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                                <?php echo e(__('file.unit_price')); ?>

                            </th>
                            <th class="px-4 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                                <?php echo e(__('file.qty')); ?>

                            </th>
                            <th class="px-4 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                                <?php echo e(__('file.line_total')); ?>

                            </th>
                        </tr>
                    </thead>
                    <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $appointment->treatments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treatment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="px-4 py-3 text-sm text-gray-900 dark:text-gray-200">
                                    <?php echo e($treatment->name); ?>

                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($treatment->code): ?>
                                        <span class="ml-1.5 text-xs text-gray-500 dark:text-gray-400">(<?php echo e($treatment->code); ?>)</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                                <td class="px-4 py-3 text-sm text-right text-gray-700 dark:text-gray-300">
                                    <?php echo e(number_format($treatment->pivot->price_at_time, 2)); ?>

                                </td>
                                <td class="px-3 py-3 text-sm text-right text-gray-700 dark:text-gray-300">
                                    <?php echo e($treatment->pivot->quantity); ?>

                                </td>
                                <td class="px-4 py-3 text-sm text-right font-medium text-gray-900 dark:text-white">
                                    <?php echo e(number_format($treatment->pivot->quantity * $treatment->pivot->price_at_time, 2)); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                    <tfoot class="bg-gray-50 dark:bg-gray-800/50 font-medium">
                        <tr>
                            <td colspan="3" class="px-4 py-3 text-right text-gray-700 dark:text-gray-300">
                                <?php echo e(__('file.total_treatments_cost')); ?>

                            </td>
                            <td class="px-4 py-3 text-right text-indigo-600 dark:text-indigo-400">
                                <?php echo e(number_format($appointment->total_treatment_price ?? 0, 2)); ?>

                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    <div id="treatmentsModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-2xl mx-4">
            <h3 class="text-lg font-semibold mb-4 text-gray-900 dark:text-white"><?php echo e(__('file.select_treatments_modal')); ?></h3>

            <form method="POST" action="<?php echo e(route('appointments.treatments.update', $appointment)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>

                <div class="mb-6 max-h-64 overflow-y-auto border border-gray-300 dark:border-gray-600 rounded-md p-3">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $treatments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treatment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="flex items-center py-1.5 hover:bg-gray-50 dark:hover:bg-gray-700 px-2 rounded cursor-pointer">
                            <input type="checkbox"
                                name="treatment_ids[]"
                                value="<?php echo e($treatment->id); ?>"
                                <?php echo e($appointment->treatments->contains($treatment->id) ? 'checked' : ''); ?>

                                class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                            <span class="ml-3 text-sm text-gray-900 dark:text-gray-200">
                                <?php echo e($treatment->name); ?>

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($treatment->code): ?> <span class="text-gray-500">(<?php echo e($treatment->code); ?>)</span> <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                - <span class="font-medium">LKR <?php echo e(number_format($treatment->price, 2)); ?></span>
                            </span>
                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <p class="mt-2 text-xs text-gray-500 dark:text-gray-400">
                    <?php echo e(__('file.check_treatments_apply')); ?>

                </p>

                <div class="flex justify-end gap-3">
                    <button type="button" onclick="document.getElementById('treatmentsModal').classList.add('hidden')"
                            class="px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded text-sm">
                        <?php echo e(__('file.cancel')); ?>

                    </button>
                    <button type="submit"
                            class="px-5 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 text-sm">
                        <?php echo e(__('file.save_selection')); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$appointment->doctor_id || !$appointment->scheduled_start): ?>
    <div class="bg-white dark:bg-gray-800 p-4 rounded mb-4">
        <h3 class="text-sm font-semibold text-gray-500 dark:text-gray-400 mb-4"><?php echo e(__('file.assign_doctor_time_slot')); ?></h3>

        <form action="<?php echo e(route('appointments.assign', $appointment)); ?>" method="POST" id="assignForm">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-sm text-gray-700 dark:text-gray-300 mb-1">
                        <?php echo e(__('file.specialization_required')); ?>

                    </label>
                    <select name="specialization_id" id="specialization_id" required
                            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded dark:bg-gray-700 dark:text-white text-sm">
                        <option value=""><?php echo e(__('file.select_specialization')); ?></option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $specializations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($spec->id); ?>"
                                    <?php echo e(($appointment->specialization_id ?? $appointment->doctor?->primarySpecialization?->id ?? old('specialization_id')) == $spec->id ? 'selected' : ''); ?>>
                                <?php echo e($spec->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </select>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['specialization_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <div>
                    <label class="block text-sm text-gray-700 dark:text-gray-300 mb-1">
                        <?php echo e(__('file.doctor_required')); ?>

                    </label>
                    <select name="doctor_id" id="doctor_id" required
                            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded dark:bg-gray-700 dark:text-white text-sm">
                        <option value=""><?php echo e(__('file.select_specialization_first')); ?></option>
                    </select>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['doctor_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <div>
                    <label class="block text-sm text-gray-700 dark:text-gray-300 mb-1">
                        <?php echo e(__('file.date_required')); ?>

                    </label>
                    <input type="date" name="date" id="date_input" min="<?php echo e(now()->format('Y-m-d')); ?>" required
                           value="<?php echo e(old('date', $appointment->scheduled_start?->format('Y-m-d') ?? '')); ?>"
                           class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded dark:bg-gray-700 dark:text-white text-sm">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <div>
                    <label class="block text-sm text-gray-700 dark:text-gray-300 mb-1">
                        <?php echo e(__('file.time_slot_required')); ?>

                    </label>
                    <select name="slot" id="slot_select" required disabled
                            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded dark:bg-gray-700 dark:text-white text-sm">
                        <option value=""><?php echo e(__('file.select_date_first')); ?></option>
                    </select>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['slot'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>

            <button type="submit" class="px-4 py-2 bg-indigo-600 text-white text-sm rounded hover:bg-indigo-700" id="assignBtn" disabled>
                <?php echo e(__('file.assign_doctor_time_slot_btn')); ?>

            </button>
        </form>
    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($appointment->patient_notes || $appointment->doctor_notes || $appointment->admin_notes): ?>
    <div class="bg-white dark:bg-gray-800 p-4 rounded mb-20">
        <h3 class="text-sm font-semibold text-gray-500 dark:text-gray-400 mb-3"><?php echo e(__('file.notes')); ?></h3>
        <div class="space-y-3">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($appointment->patient_notes): ?>
            <div>
                <p class="text-xs font-medium text-gray-500"><?php echo e(__('file.patient_notes')); ?></p>
                <p class="text-sm text-gray-700 dark:text-gray-300 mt-1"><?php echo e($appointment->patient_notes); ?></p>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($appointment->doctor_notes): ?>
            <div>
                <p class="text-xs font-medium text-gray-500"><?php echo e(__('file.doctor_notes')); ?></p>
                <p class="text-sm text-gray-700 dark:text-gray-300 mt-1"><?php echo e($appointment->doctor_notes); ?></p>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($appointment->admin_notes): ?>
            <div>
                <p class="text-xs font-medium text-gray-500"><?php echo e(__('file.admin_notes')); ?></p>
                <p class="text-sm text-gray-700 dark:text-gray-300 mt-1"><?php echo e($appointment->admin_notes); ?></p>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($appointment->status === 'pending'): ?>
<div class="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 px-4 py-3 z-10">
    <div class="max-w-6xl mx-auto flex gap-3 justify-end">
        <button type="button" onclick="document.getElementById('rejectModal').classList.remove('hidden')"
                class="px-6 py-2 bg-red-600 text-white text-sm rounded hover:bg-red-700">
            <?php echo e(__('file.reject')); ?>

        </button>
        <form action="<?php echo e(route('appointments.approve', $appointment)); ?>" method="POST" class="inline">
            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
            <button type="submit" onclick="return confirm('<?php echo e(__('file.approve_confirm')); ?>')"
                    class="px-6 py-2 bg-green-600 text-white text-sm rounded hover:bg-green-700">
                <?php echo e(__('file.approve')); ?>

            </button>
        </form>
    </div>
</div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($appointment->status === 'approved'): ?>
    <div class="mt-6 flex justify-end gap-3">
        <a href="<?php echo e(route('appointments.prescription.create', $appointment)); ?>"
           class="inline-flex items-center px-5 py-2.5 bg-green-600 hover:bg-green-700 text-white text-sm font-medium rounded-lg shadow-sm transition">
            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
            </svg>
            <?php echo e(__('file.create_prescription')); ?>

        </a>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($appointment->prescriptions()->exists()): ?>
            <a href="<?php echo e(route('prescriptions.show', $appointment->prescriptions->first())); ?>"
               class="inline-flex items-center px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded-lg shadow-sm transition">
                <?php echo e(__('file.view_prescription')); ?>

            </a>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<div id="rejectModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white dark:bg-gray-800 rounded p-6 w-full max-w-md mx-4">
        <h3 class="text-lg font-semibold mb-4 text-gray-900 dark:text-white"><?php echo e(__('file.reject_appointment')); ?></h3>
        <form id="rejectForm" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <textarea name="rejection_reason" rows="4"
                      class="w-full rounded border-gray-300 dark:border-gray-600 dark:bg-gray-700 text-gray-900 dark:text-white text-sm"
                      placeholder="<?php echo e(__('file.reason_for_rejection_optional')); ?>"></textarea>
            <div class="mt-4 flex justify-end gap-2">
                <button type="button" onclick="document.getElementById('rejectModal').classList.add('hidden')"
                        class="px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded text-sm">
                    <?php echo e(__('file.cancel')); ?>

                </button>
                <button type="submit"
                        class="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 text-sm">
                    <?php echo e(__('file.confirm_reject')); ?>

                </button>
            </div>
        </form>
    </div>
</div>

<script>
document.getElementById('rejectForm').action = "<?php echo e(route('appointments.reject', $appointment)); ?>";

document.addEventListener('DOMContentLoaded', function () {
    const specSelect   = document.getElementById('specialization_id');
    const doctorSelect = document.getElementById('doctor_id');
    const dateInput    = document.getElementById('date_input');
    const slotSelect   = document.getElementById('slot_select');
    const assignBtn    = document.getElementById('assignBtn');

    const preDoctorId = '<?php echo e($appointment->doctor_id ?? ""); ?>';
    const hasDoctor   = !!preDoctorId;

    function resetSlots() {
        slotSelect.innerHTML = '<option value=""><?php echo e(__('file.select_date_first')); ?></option>';
        slotSelect.disabled = true;
        assignBtn.disabled = true;
    }

    function updateButton() {
        const hasSlot = slotSelect.value && slotSelect.value.trim() !== '';
        assignBtn.disabled = !hasSlot;
    }

    function loadSlots() {
        const doctorId = doctorSelect?.value || preDoctorId;
        const date = dateInput.value;

        resetSlots();

        if (!doctorId || !date) return;

        slotSelect.disabled = false;
        slotSelect.innerHTML = '<option value="">Loading time slots...</option>';

        const url = '<?php echo e(route("doctors.available-slots", ":doctor")); ?>'
            .replace(':doctor', doctorId) + '?date=' + encodeURIComponent(date);

        fetch(url)
            .then(r => { if (!r.ok) throw new Error(); return r.json(); })
            .then(data => {
                slotSelect.innerHTML = '<option value=""><?php echo e(__('file.select_time_slot')); ?></option>';
                if (data.slots?.length) {
                    data.slots.forEach(s => {
                        const opt = document.createElement('option');
                        opt.value = s.start + '|' + s.end;
                        opt.textContent = s.label;

                        if ('<?php echo e($appointment->scheduled_start?->format('H:i') ?? ''); ?>' === s.start &&
                            '<?php echo e($appointment->scheduled_end?->format('H:i')   ?? ''); ?>' === s.end) {
                            opt.selected = true;
                        }
                        slotSelect.appendChild(opt);
                    });
                } else {
                    slotSelect.innerHTML = '<option value="">No available slots</option>';
                }
                updateButton();
            })
            .catch(() => {
                slotSelect.innerHTML = '<option value="">Error loading slots</option>';
            });
    }

    function loadDoctors(afterLoad = null) {
        const specId = specSelect.value;
        if (!specId) {
            doctorSelect.innerHTML = '<option value=""><?php echo e(__('file.select_specialization_first')); ?></option>';
            resetSlots();
            updateButton();
            return;
        }

        doctorSelect.innerHTML = '<option value="">Loading doctors...</option>';

        const url = '<?php echo e(route("appointments.doctors.by_specialization", ":specialization_id")); ?>'
            .replace(':specialization_id', specId);

        fetch(url)
            .then(r => { if (!r.ok) throw new Error(); return r.json(); })
            .then(data => {
                doctorSelect.innerHTML = '<option value=""><?php echo e(__('file.select_doctor')); ?></option>';
                data.forEach(d => {
                    const opt = document.createElement('option');
                    opt.value = d.value;
                    opt.textContent = d.text;
                    doctorSelect.appendChild(opt);
                });

                if (preDoctorId) {
                    const match = Array.from(doctorSelect.options).find(o => o.value === preDoctorId);
                    if (match) match.selected = true;
                }

                if (typeof afterLoad === 'function') afterLoad();
                updateButton();
            })
            .catch(() => {
                doctorSelect.innerHTML = '<option value="">Error loading doctors</option>';
            });
    }

    if (specSelect && doctorSelect) {
        specSelect.addEventListener('change', () => {
            loadDoctors(() => {
                resetSlots();
                if (dateInput.value) loadSlots();
            });
        });

        doctorSelect.addEventListener('change', () => {
            resetSlots();
            if (dateInput.value) loadSlots();
        });
    }

    dateInput.addEventListener('change', () => {
        if ((doctorSelect?.value || preDoctorId) && dateInput.value) {
            loadSlots();
        }
    });

    slotSelect.addEventListener('change', updateButton);

    if (hasDoctor) {
        const initialSpec = '<?php echo e($appointment->doctor?->primarySpecialization?->id ?? $appointment->specialization_id ?? ""); ?>';
        if (initialSpec && specSelect) {
            const opt = Array.from(specSelect.options).find(o => o.value === initialSpec);
            if (opt) opt.selected = true;

            loadDoctors(() => {
                if (dateInput.value) loadSlots();
            });
        }
    } else if (specSelect?.value) {
        loadDoctors();
    }

    updateButton();
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Program Files\xampp\htdocs\test\appointmentsystem\docappointment\resources\views/appointments/show.blade.php ENDPATH**/ ?>