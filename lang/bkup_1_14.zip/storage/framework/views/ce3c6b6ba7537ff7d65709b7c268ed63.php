

<?php $__env->startSection('title', 'Inventory Items'); ?>

<?php $__env->startSection('content'); ?>
<div class="px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
    <!-- Header -->
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6 sm:mb-8">
        <div>
            <h1 class="text-2xl sm:text-3xl font-semibold text-gray-900 dark:text-white">Inventory Items</h1>
            <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">Manage and track inventory stock levels</p>
        </div>
        <a href="<?php echo e(route('inventoryitems.create')); ?>"
           class="inline-flex items-center px-3 py-2 sm:px-4 sm:py-2.5 bg-gray-900 dark:bg-gray-700 text-white text-sm font-medium rounded-lg hover:bg-gray-800 dark:hover:bg-gray-600 transition-colors duration-200 shadow-sm whitespace-nowrap">
            <svg class="w-4 h-4 mr-1 sm:mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
            </svg>
            <span class="sm:inline">Add Item</span>
        </a>
    </div>

    <!-- Search & Filters -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4 mb-5 sm:mb-6">
        <form method="GET" id="search-form" class="flex flex-col gap-3">
            <div class="flex-1">
                <input type="text" 
                       name="search" 
                       value="<?php echo e(request('search')); ?>"
                       placeholder="Search by name, SKU, brand, manufacturer..."
                       class="w-full px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-gray-900 dark:focus:ring-gray-500 focus:border-transparent dark:bg-gray-700 dark:text-white transition-shadow">
            </div>

            <div class="flex gap-2">
                <button type="submit"
                        class="flex-1 sm:flex-initial inline-flex items-center justify-center px-4 py-2 bg-gray-900 dark:bg-gray-700 text-white text-sm font-medium rounded-lg hover:bg-gray-800 dark:hover:bg-gray-600 transition-colors duration-200">
                    <svg class="w-4 h-4 mr-1 sm:mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                              d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                    </svg>
                    <span class="hidden sm:inline">Search</span>
                </button>

                <a href="<?php echo e(route('inventoryitems.index')); ?>"
                   class="flex-1 sm:flex-initial inline-flex items-center justify-center px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 text-sm font-medium rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors duration-200">
                    Clear
                </a>
            </div>
        </form>
    </div>

    <!-- Bulk Delete Form -->
    <form method="POST" action="<?php echo e(route('inventoryitems.bulkDelete')); ?>" id="bulk-delete-form" class="hidden mb-4">
        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
        <input type="hidden" name="ids" id="bulk-ids">
        <div class="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-3 sm:p-4">
            <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <span class="text-sm text-red-800 dark:text-red-300">
                    <span id="selected-count">0</span> item(s) selected
                </span>
                <button type="submit" 
                        onclick="return confirm('Are you sure you want to delete the selected items?')"
                        class="w-full sm:w-auto inline-flex items-center justify-center px-3 py-2 bg-red-600 text-white text-sm font-medium rounded-lg hover:bg-red-700 transition-colors duration-200">
                    <svg class="w-4 h-4 mr-1 sm:mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                              d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                    </svg>
                    Delete
                </button>
            </div>
        </div>
    </form>

    <!-- Results Info (Mobile Only) -->
    <div class="sm:hidden text-sm text-gray-600 dark:text-gray-400 mb-3">
        Showing <?php echo e($items->firstItem()); ?> to <?php echo e($items->lastItem()); ?> of <?php echo e($items->total()); ?> results
    </div>

    <!-- Mobile Sort Controls -->
    <div class="sm:hidden mb-4 bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4">
        <h3 class="text-sm font-medium text-gray-900 dark:text-white mb-3">Sort by</h3>
        <div class="grid grid-cols-2 gap-2 text-sm">
            <?php if (isset($component)) { $__componentOriginalb67281f77a791c7d418e1c0be2caa755 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb67281f77a791c7d418e1c0be2caa755 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sort-link','data' => ['field' => 'name','sort' => $sort,'direction' => $direction]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sort-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'name','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'direction' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($direction)]); ?>Name <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb67281f77a791c7d418e1c0be2caa755)): ?>
<?php $attributes = $__attributesOriginalb67281f77a791c7d418e1c0be2caa755; ?>
<?php unset($__attributesOriginalb67281f77a791c7d418e1c0be2caa755); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb67281f77a791c7d418e1c0be2caa755)): ?>
<?php $component = $__componentOriginalb67281f77a791c7d418e1c0be2caa755; ?>
<?php unset($__componentOriginalb67281f77a791c7d418e1c0be2caa755); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalb67281f77a791c7d418e1c0be2caa755 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb67281f77a791c7d418e1c0be2caa755 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sort-link','data' => ['field' => 'sku','sort' => $sort,'direction' => $direction]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sort-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'sku','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'direction' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($direction)]); ?>SKU <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb67281f77a791c7d418e1c0be2caa755)): ?>
<?php $attributes = $__attributesOriginalb67281f77a791c7d418e1c0be2caa755; ?>
<?php unset($__attributesOriginalb67281f77a791c7d418e1c0be2caa755); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb67281f77a791c7d418e1c0be2caa755)): ?>
<?php $component = $__componentOriginalb67281f77a791c7d418e1c0be2caa755; ?>
<?php unset($__componentOriginalb67281f77a791c7d418e1c0be2caa755); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalb67281f77a791c7d418e1c0be2caa755 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb67281f77a791c7d418e1c0be2caa755 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sort-link','data' => ['field' => 'current_stock','sort' => $sort,'direction' => $direction]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sort-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'current_stock','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'direction' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($direction)]); ?>Stock <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb67281f77a791c7d418e1c0be2caa755)): ?>
<?php $attributes = $__attributesOriginalb67281f77a791c7d418e1c0be2caa755; ?>
<?php unset($__attributesOriginalb67281f77a791c7d418e1c0be2caa755); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb67281f77a791c7d418e1c0be2caa755)): ?>
<?php $component = $__componentOriginalb67281f77a791c7d418e1c0be2caa755; ?>
<?php unset($__componentOriginalb67281f77a791c7d418e1c0be2caa755); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalb67281f77a791c7d418e1c0be2caa755 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb67281f77a791c7d418e1c0be2caa755 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sort-link','data' => ['field' => 'unit_price','sort' => $sort,'direction' => $direction]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sort-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'unit_price','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'direction' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($direction)]); ?>Price <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb67281f77a791c7d418e1c0be2caa755)): ?>
<?php $attributes = $__attributesOriginalb67281f77a791c7d418e1c0be2caa755; ?>
<?php unset($__attributesOriginalb67281f77a791c7d418e1c0be2caa755); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb67281f77a791c7d418e1c0be2caa755)): ?>
<?php $component = $__componentOriginalb67281f77a791c7d418e1c0be2caa755; ?>
<?php unset($__componentOriginalb67281f77a791c7d418e1c0be2caa755); ?>
<?php endif; ?>
        </div>
    </div>

    <!-- Table (Mobile Cards + Desktop Table) -->
    <div class="space-y-4 sm:hidden">
        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4">
                <div class="flex items-start justify-between mb-3">
                    <div class="flex items-center gap-3">
                        <input type="checkbox" name="ids[]" value="<?php echo e($item->id); ?>" class="row-checkbox w-4 h-4 rounded border-gray-300 dark:border-gray-600 text-gray-900 focus:ring-2 focus:ring-gray-900 dark:focus:ring-gray-500">
                        <div>
                            <div class="font-medium text-gray-900 dark:text-white"><?php echo e($item->name); ?></div>
                            <div class="text-xs text-gray-500 dark:text-gray-400 font-mono"><?php echo e($item->sku); ?></div>
                        </div>
                    </div>
                    <div class="text-right">
                        <div class="text-sm font-medium <?php echo e($item->current_stock <= $item->reorder_point ? 'text-red-600 dark:text-red-400' : 'text-green-600 dark:text-green-400'); ?>">
                            <?php echo e($item->current_stock); ?> <?php echo e($item->unitOfMeasure?->abbreviation ?? 'units'); ?>

                        </div>
                        <?php if($item->current_stock == 0): ?>
                            <span class="inline-block px-2 py-0.5 mt-1 text-xs font-medium bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-300 rounded">Out of Stock</span>
                        <?php elseif($item->current_stock <= $item->reorder_point): ?>
                            <span class="inline-block px-2 py-0.5 mt-1 text-xs font-medium bg-orange-100 dark:bg-orange-900/30 text-orange-800 dark:text-orange-300 rounded">Low Stock</span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-x-4 gap-y-2 text-sm mb-4">
                    <div>
                        <div class="text-gray-500 dark:text-gray-400 text-xs">Category</div>
                        <div class="truncate"><?php echo e($item->category?->name ?? '—'); ?></div>
                    </div>
                    <div>
                        <div class="text-gray-500 dark:text-gray-400 text-xs">Brand</div>
                        <div><?php echo e($item->brand ?? '—'); ?></div>
                    </div>
                    <div>
                        <div class="text-gray-500 dark:text-gray-400 text-xs">Unit Price</div>
                        <div>LKR <?php echo e(number_format($item->unit_price, 2)); ?></div>
                    </div>
                    <div>
                        <div class="text-gray-500 dark:text-gray-400 text-xs">Value</div>
                        <div>LKR <?php echo e(number_format($item->total_value, 2)); ?></div>
                    </div>
                </div>

                <div class="flex justify-end gap-2">
                    <button onclick="openProfileDrawer(<?php echo e($item->toJson()); ?>)"
                            class="p-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                  d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                  d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                        </svg>
                    </button>
                    <a href="<?php echo e(route('inventoryitems.edit', $item)); ?>"
                       class="p-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                  d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                        </svg>
                    </a>
                    <form method="POST" action="<?php echo e(route('inventoryitems.destroy', $item)); ?>" class="inline">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button type="submit"
                                onclick="return confirm('Are you sure you want to delete this item?')"
                                class="p-2 text-gray-600 dark:text-gray-400 hover:text-red-600 dark:hover:text-red-500 transition-colors">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                      d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                            </svg>
                        </button>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="text-center py-12">
                <svg class="mx-auto h-12 w-12 text-gray-400 dark:text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"/>
                </svg>
                <p class="mt-4 text-sm text-gray-500 dark:text-gray-400">No inventory items found</p>
            </div>
        <?php endif; ?>
    </div>

    <!-- Desktop Table -->
    <div class="hidden sm:block bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead class="bg-gray-50 dark:bg-gray-900/50">
                    <tr>
                        <th class="px-4 py-3 text-left">
                            <input type="checkbox" id="select-all" class="w-4 h-4 rounded border-gray-300 dark:border-gray-600 text-gray-900 focus:ring-2 focus:ring-gray-900 dark:focus:ring-gray-500">
                        </th>
                        <th class="px-4 py-3 text-left text-xs font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wider">
                            <?php if (isset($component)) { $__componentOriginalb67281f77a791c7d418e1c0be2caa755 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb67281f77a791c7d418e1c0be2caa755 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sort-link','data' => ['field' => 'name','sort' => $sort,'direction' => $direction]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sort-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'name','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'direction' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($direction)]); ?>Name <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb67281f77a791c7d418e1c0be2caa755)): ?>
<?php $attributes = $__attributesOriginalb67281f77a791c7d418e1c0be2caa755; ?>
<?php unset($__attributesOriginalb67281f77a791c7d418e1c0be2caa755); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb67281f77a791c7d418e1c0be2caa755)): ?>
<?php $component = $__componentOriginalb67281f77a791c7d418e1c0be2caa755; ?>
<?php unset($__componentOriginalb67281f77a791c7d418e1c0be2caa755); ?>
<?php endif; ?>
                        </th>
                        <th class="px-4 py-3 text-left text-xs font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wider">
                            <?php if (isset($component)) { $__componentOriginalb67281f77a791c7d418e1c0be2caa755 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb67281f77a791c7d418e1c0be2caa755 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sort-link','data' => ['field' => 'sku','sort' => $sort,'direction' => $direction]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sort-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'sku','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'direction' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($direction)]); ?>SKU <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb67281f77a791c7d418e1c0be2caa755)): ?>
<?php $attributes = $__attributesOriginalb67281f77a791c7d418e1c0be2caa755; ?>
<?php unset($__attributesOriginalb67281f77a791c7d418e1c0be2caa755); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb67281f77a791c7d418e1c0be2caa755)): ?>
<?php $component = $__componentOriginalb67281f77a791c7d418e1c0be2caa755; ?>
<?php unset($__componentOriginalb67281f77a791c7d418e1c0be2caa755); ?>
<?php endif; ?>
                        </th>
                        <th class="px-4 py-3 text-left text-xs font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wider">
                            Category
                        </th>
                        <th class="px-4 py-3 text-left text-xs font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wider">
                            <?php if (isset($component)) { $__componentOriginalb67281f77a791c7d418e1c0be2caa755 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb67281f77a791c7d418e1c0be2caa755 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sort-link','data' => ['field' => 'current_stock','sort' => $sort,'direction' => $direction]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sort-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'current_stock','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'direction' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($direction)]); ?>Stock <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb67281f77a791c7d418e1c0be2caa755)): ?>
<?php $attributes = $__attributesOriginalb67281f77a791c7d418e1c0be2caa755; ?>
<?php unset($__attributesOriginalb67281f77a791c7d418e1c0be2caa755); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb67281f77a791c7d418e1c0be2caa755)): ?>
<?php $component = $__componentOriginalb67281f77a791c7d418e1c0be2caa755; ?>
<?php unset($__componentOriginalb67281f77a791c7d418e1c0be2caa755); ?>
<?php endif; ?>
                        </th>
                        <th class="px-4 py-3 text-left text-xs font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wider">
                            <?php if (isset($component)) { $__componentOriginalb67281f77a791c7d418e1c0be2caa755 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb67281f77a791c7d418e1c0be2caa755 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sort-link','data' => ['field' => 'unit_price','sort' => $sort,'direction' => $direction]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sort-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'unit_price','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'direction' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($direction)]); ?>Unit Price <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb67281f77a791c7d418e1c0be2caa755)): ?>
<?php $attributes = $__attributesOriginalb67281f77a791c7d418e1c0be2caa755; ?>
<?php unset($__attributesOriginalb67281f77a791c7d418e1c0be2caa755); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb67281f77a791c7d418e1c0be2caa755)): ?>
<?php $component = $__componentOriginalb67281f77a791c7d418e1c0be2caa755; ?>
<?php unset($__componentOriginalb67281f77a791c7d418e1c0be2caa755); ?>
<?php endif; ?>
                        </th>
                        <th class="px-4 py-3 text-left text-xs font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wider">
                            Total Value
                        </th>
                        <th class="px-4 py-3 text-left text-xs font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wider">
                            Actions
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                    <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-gray-50 dark:hover:bg-gray-900/30 transition-colors duration-150">
                            <td class="px-4 py-3 whitespace-nowrap">
                                <input type="checkbox" name="ids[]" value="<?php echo e($item->id); ?>" class="row-checkbox w-4 h-4 rounded border-gray-300 dark:border-gray-600 text-gray-900 focus:ring-2 focus:ring-gray-900 dark:focus:ring-gray-500">
                            </td>
                            <td class="px-4 py-3 whitespace-nowrap">
                                <div class="text-sm font-medium text-gray-900 dark:text-white"><?php echo e($item->name); ?></div>
                                <div class="text-xs text-gray-500 dark:text-gray-400"><?php echo e($item->brand ?? ''); ?></div>
                            </td>
                            <td class="px-4 py-3 whitespace-nowrap">
                                <div class="text-sm text-gray-600 dark:text-gray-300 font-mono"><?php echo e($item->sku); ?></div>
                            </td>
                            <td class="px-4 py-3 whitespace-nowrap">
                                <div class="text-sm text-gray-600 dark:text-gray-300"><?php echo e($item->category?->name ?? '—'); ?></div>
                            </td>
                            <td class="px-4 py-3 whitespace-nowrap">
                                <div class="text-sm font-medium <?php echo e($item->current_stock <= $item->reorder_point ? 'text-red-600 dark:text-red-400' : 'text-green-600 dark:text-green-400'); ?>">
                                    <?php echo e($item->current_stock); ?> <?php echo e($item->unitOfMeasure?->abbreviation ?? ''); ?>

                                </div>
                                <?php if($item->current_stock == 0): ?>
                                    <span class="inline-block px-2 py-0.5 mt-1 text-xs font-medium bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-300 rounded">Out</span>
                                <?php elseif($item->current_stock <= $item->reorder_point): ?>
                                    <span class="inline-block px-2 py-0.5 mt-1 text-xs font-medium bg-orange-100 dark:bg-orange-900/30 text-orange-800 dark:text-orange-300 rounded">Low</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-4 py-3 whitespace-nowrap">
                                <div class="text-sm text-gray-600 dark:text-gray-300">LKR <?php echo e(number_format($item->unit_price, 2)); ?></div>
                            </td>
                            <td class="px-4 py-3 whitespace-nowrap">
                                <div class="text-sm text-gray-600 dark:text-gray-300 font-medium">LKR <?php echo e(number_format($item->total_value, 2)); ?></div>
                            </td>
                            <td class="px-4 py-3 whitespace-nowrap">
                                <div class="flex items-center gap-2">
                                    <button onclick="openProfileDrawer(<?php echo e($item->toJson()); ?>)"
                                            class="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors" 
                                            title="View Details">
                                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                  d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                  d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                                        </svg>
                                    </button>
                                    <a href="<?php echo e(route('inventoryitems.edit', $item)); ?>"
                                       class="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors" 
                                       title="Edit">
                                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                  d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                                        </svg>
                                    </a>
                                    <form method="POST" action="<?php echo e(route('inventoryitems.destroy', $item)); ?>" class="inline">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit"
                                                onclick="return confirm('Are you sure you want to delete this item?')"
                                                class="text-gray-600 dark:text-gray-400 hover:text-red-600 dark:hover:text-red-500 transition-colors" 
                                                title="Delete">
                                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                      d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                                            </svg>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="px-6 py-12 text-center">
                                <svg class="mx-auto h-12 w-12 text-gray-400 dark:text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"/>
                                </svg>
                                <p class="mt-4 text-sm text-gray-500 dark:text-gray-400">No inventory items found</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Mobile Pagination -->
    <div class="mt-6 sm:hidden">
        <?php echo e($items->appends(request()->query())->links()); ?>

    </div>

    <!-- Desktop Pagination -->
    <div class="hidden sm:block mt-6">
        <?php echo e($items->appends(request()->query())->links()); ?>

    </div>
</div>


<div id="profile-drawer" class="fixed inset-0 z-50 hidden overflow-hidden">
    <div id="drawer-overlay"
         class="absolute inset-0 bg-gray-900/60 dark:bg-black/80 backdrop-blur-sm transition-opacity duration-300 opacity-0"
         onclick="closeProfileDrawer()"></div>

    <div id="drawer-panel"
         class="absolute inset-x-0 bottom-0 md:inset-y-0 md:right-0 md:left-auto
                w-full md:max-w-md bg-white dark:bg-gray-800 shadow-2xl flex flex-col
                transform transition-transform duration-300 ease-out
                translate-y-full md:translate-y-0 md:translate-x-full
                h-[90vh] md:h-full rounded-t-3xl md:rounded-none">
        
        <div class="md:hidden flex justify-center pt-4 pb-2">
            <div class="w-12 h-1.5 bg-gray-300 dark:bg-gray-600 rounded-full"></div>
        </div>

        <div class="flex items-center justify-between px-5 py-4 border-b border-gray-200 dark:border-gray-700">
            <div>
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white" id="drawer-name"></h3>
                <p class="text-xs text-gray-500 dark:text-gray-400">Item Details</p>
            </div>
            <button onclick="closeProfileDrawer()"
                    class="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors p-1">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                </svg>
            </button>
        </div>

        <div class="flex-1 overflow-y-auto overscroll-contain px-5 py-5 text-sm">
            <div class="space-y-5">
                <div>
                    <h4 class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2">Basic Info</h4>
                    <div class="grid grid-cols-1 gap-3">
                        <div>
                            <label class="text-xs text-gray-500 dark:text-gray-400">SKU</label>
                            <div class="font-mono text-gray-900 dark:text-white" id="drawer-sku"></div>
                        </div>
                        <div>
                            <label class="text-xs text-gray-500 dark:text-gray-400">Category</label>
                            <div class="text-gray-900 dark:text-white" id="drawer-category"></div>
                        </div>
                        <div>
                            <label class="text-xs text-gray-500 dark:text-gray-400">Subcategory</label>
                            <div class="text-gray-900 dark:text-white" id="drawer-subcategory"></div>
                        </div>
                    </div>
                </div>

                <div>
                    <h4 class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2">Stock & Pricing</h4>
                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="text-xs text-gray-500 dark:text-gray-400">Current Stock</label>
                            <div class="text-gray-900 dark:text-white font-medium" id="drawer-stock"></div>
                        </div>
                        <div>
                            <label class="text-xs text-gray-500 dark:text-gray-400">Unit</label>
                            <div class="text-gray-900 dark:text-white" id="drawer-unit"></div>
                        </div>
                        <div>
                            <label class="text-xs text-gray-500 dark:text-gray-400">Unit Cost</label>
                            <div class="text-gray-900 dark:text-white">LKR <span id="drawer-cost"></span></div>
                        </div>
                        <div>
                            <label class="text-xs text-gray-500 dark:text-gray-400">Unit Price</label>
                            <div class="text-gray-900 dark:text-white">LKR <span id="drawer-price"></span></div>
                        </div>
                        <div>
                            <label class="text-xs text-gray-500 dark:text-gray-400">Total Value</label>
                            <div class="text-gray-900 dark:text-white font-medium">LKR <span id="drawer-value"></span></div>
                        </div>
                        <div>
                            <label class="text-xs text-gray-500 dark:text-gray-400">Reorder Point</label>
                            <div class="text-gray-900 dark:text-white" id="drawer-reorder"></div>
                        </div>
                    </div>
                </div>

                <div>
                    <h4 class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2">Properties</h4>
                    <div class="flex flex-wrap gap-2">
                        <span id="drawer-refrigeration" class="hidden px-2.5 py-1 rounded text-xs font-medium bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300">Requires Refrigeration</span>
                        <span id="drawer-controlled" class="hidden px-2.5 py-1 rounded text-xs font-medium bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-300">Controlled Substance</span>
                        <span id="drawer-hazardous" class="hidden px-2.5 py-1 rounded text-xs font-medium bg-orange-100 dark:bg-orange-900/30 text-orange-800 dark:text-orange-300">Hazardous</span>
                        <span id="drawer-sterile" class="hidden px-2.5 py-1 rounded text-xs font-medium bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300">Sterile</span>
                    </div>
                </div>

                <div>
                    <h4 class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-1">Manufacturer & Brand</h4>
                    <div class="grid grid-cols-1 gap-3">
                        <div>
                            <label class="text-xs text-gray-500 dark:text-gray-400">Manufacturer</label>
                            <div class="text-gray-900 dark:text-white" id="drawer-manufacturer"></div>
                        </div>
                        <div>
                            <label class="text-xs text-gray-500 dark:text-gray-400">Brand</label>
                            <div class="text-gray-900 dark:text-white" id="drawer-brand"></div>
                        </div>
                        <div>
                            <label class="text-xs text-gray-500 dark:text-gray-400">Model</label>
                            <div class="text-gray-900 dark:text-white" id="drawer-model"></div>
                        </div>
                    </div>
                </div>

                <div>
                    <h4 class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-1">Supplier</h4>
                    <div class="text-gray-900 dark:text-white" id="drawer-supplier"></div>
                </div>
            </div>
        </div>

        <div class="px-5 py-3 bg-gray-50 dark:bg-gray-900/50 border-t border-gray-200 dark:border-gray-700">
            <button onclick="closeProfileDrawer()"
                    class="w-full px-4 py-2 bg-gray-900 dark:bg-gray-700 text-white text-sm font-medium rounded-lg hover:bg-gray-800 dark:hover:bg-gray-600 transition-colors duration-200">
                Close
            </button>
        </div>
    </div>
</div>

<style>
    html, body {
        overscroll-behavior-y: contain;
    }
</style>

<script>
    document.getElementById('select-all')?.addEventListener('change', function () {
        document.querySelectorAll('.row-checkbox').forEach(cb => cb.checked = this.checked);
        updateBulkDelete();
    });
    document.querySelectorAll('.row-checkbox').forEach(cb => cb.addEventListener('change', updateBulkDelete));

    function updateBulkDelete() {
        const checked = document.querySelectorAll('.row-checkbox:checked');
        const count = checked.length;
        const form = document.getElementById('bulk-delete-form');
        const idsInput = document.getElementById('bulk-ids');
        const countSpan = document.getElementById('selected-count');

        if (count > 0) {
            form.classList.remove('hidden');
            idsInput.value = Array.from(checked).map(cb => cb.value).join(',');
            countSpan.textContent = count;
        } else {
            form.classList.add('hidden');
        }
    }

    const drawer = document.getElementById('profile-drawer');
    const panel = document.getElementById('drawer-panel');
    const drawerOverlay = document.getElementById('drawer-overlay');
    let bodyScrollPosition = 0;

    function openProfileDrawer(item) {
        document.getElementById('drawer-name').textContent = item.name;
        document.getElementById('drawer-sku').textContent = item.sku;
        document.getElementById('drawer-category').textContent = item.category?.name || '—';
        document.getElementById('drawer-subcategory').textContent = item.subcategory?.name || '—';
        document.getElementById('drawer-stock').textContent = item.current_stock + ' ' + (item.unitOfMeasure?.abbreviation || '');
        document.getElementById('drawer-unit').textContent = item.unitOfMeasure?.display_name || item.unit_of_measure;
        document.getElementById('drawer-cost').textContent = parseFloat(item.unit_cost).toFixed(2);
        document.getElementById('drawer-price').textContent = parseFloat(item.unit_price).toFixed(2);
        document.getElementById('drawer-value').textContent = parseFloat(item.total_value).toFixed(2);
        document.getElementById('drawer-reorder').textContent = item.reorder_point;

        document.getElementById('drawer-manufacturer').textContent = item.manufacturer || '—';
        document.getElementById('drawer-brand').textContent = item.brand || '—';
        document.getElementById('drawer-model').textContent = item.model_version || '—';
        document.getElementById('drawer-supplier').textContent = item.primarySupplier?.name || '—';

        ['refrigeration', 'controlled', 'hazardous', 'sterile'].forEach(prop => {
            const el = document.getElementById('drawer-' + prop);
            if (item['requires_' + prop] === true || item[prop] === true) {
                el.classList.remove('hidden');
            } else {
                el.classList.add('hidden');
            }
        });

        bodyScrollPosition = window.pageYOffset;
        document.body.style.position = 'fixed';
        document.body.style.top = `-${bodyScrollPosition}px`;
        document.body.style.width = '100%';
        document.body.style.overflowY = 'scroll';

        drawer.classList.remove('hidden');
        drawerOverlay.classList.remove('opacity-0');
        drawerOverlay.classList.add('opacity-100');
        panel.classList.remove('translate-y-full', 'md:translate-x-full');
    }

    function closeProfileDrawer() {
        document.body.style.position = '';
        document.body.style.top = '';
        document.body.style.width = '';
        document.body.style.overflowY = '';
        window.scrollTo(0, bodyScrollPosition);

        drawerOverlay.classList.remove('opacity-100');
        drawerOverlay.classList.add('opacity-0');
        panel.classList.add(window.innerWidth < 640 ? 'translate-y-full' : 'md:translate-x-full');
        setTimeout(() => drawer.classList.add('hidden'), 300);
    }

    document.addEventListener('keydown', e => {
        if (e.key === 'Escape' && !drawer.classList.contains('hidden')) closeProfileDrawer();
    });

    let startY = 0;
    panel.addEventListener('touchstart', e => {
        if (window.innerWidth >= 640) return;
        startY = e.touches[0].clientY;
    }, {passive: true});
    panel.addEventListener('touchmove', e => {
        if (window.innerWidth >= 640) return;
        const delta = e.touches[0].clientY - startY;
        if (delta > 0) panel.style.transform = `translateY(${delta}px)`;
    }, {passive: true});
    panel.addEventListener('touchend', e => {
        if (window.innerWidth >= 640) return;
        const delta = e.changedTouches[0].clientY - startY;
        if (delta > 100) closeProfileDrawer();
        else panel.style.transform = '';
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Program Files\xampp\htdocs\test\appointmentsystem\docappointment\resources\views/inventoryitems/index.blade.php ENDPATH**/ ?>