

<?php $__env->startSection('content'); ?>
<div class="px-4 sm:px-6 lg:px-4 pb-4 sm:py-12 pt-20">

    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
        <div>
            <h1 class="text-3xl font-semibold tracking-tight text-gray-900 dark:text-white">
                <?php echo e(__('file.daily_queue')); ?>

            </h1>
            <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">
                <?php echo e($date->format('D, M d, Y')); ?>

            </p>
        </div>

        <form method="GET" class="flex items-center gap-2 w-full sm:w-auto">
            <input type="date" 
                   name="date" 
                   value="<?php echo e($date->format('Y-m-d')); ?>"
                   class="w-full px-2 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-gray-900 dark:focus:ring-gray-500 focus:border-transparent dark:bg-transparent dark:text-white [color-scheme:light] dark:[color-scheme:dark] transition-shadow">
            <button type="submit" 
                    class="h-11 px-5 text-sm font-medium bg-gray-900 dark:bg-gray-700 text-white rounded-lg hover:bg-gray-800 dark:hover:bg-gray-600 whitespace-nowrap transition-colors">
                <?php echo e(__('file.filter')); ?>

            </button>
        </form>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($queues->isEmpty()): ?>
        <div class="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-12 text-center">
            <p class="text-sm text-gray-500 dark:text-gray-400">
                <?php echo e(__('file.no_approved_appointments_queued')); ?>

            </p>
        </div>
    <?php else: ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $queues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg mb-6 overflow-hidden">
                <div class="px-6 py-5 border-b border-gray-200 dark:border-gray-700">
                    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                        <div>
                            <h2 class="text-xl font-semibold text-gray-900 dark:text-white">
                                <?php echo e($session['session_key']); ?>

                            </h2>
                            <p class="text-base text-gray-500 dark:text-gray-400 mt-1">
                                <?php echo e($session['doctor_name']); ?>

                            </p>
                        </div>
                        <span class="inline-flex items-center px-3 py-1 rounded text-sm font-medium bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300">
                            <?php echo e($session['patients']->count()); ?> <?php echo e(Str::plural(__('file.patient'), $session['patients']->count())); ?>

                        </span>
                    </div>
                </div>

                <div class="divide-y divide-gray-200 dark:divide-gray-700">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $session['patients']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="px-6 py-5 flex flex-col sm:flex-row sm:items-center justify-between gap-5 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                            
                            <div class="flex items-center gap-6 flex-1">
                                <div class="text-4xl font-bold text-gray-900 dark:text-white w-16 shrink-0">
                                    #<?php echo e($patient['queue_number']); ?>

                                </div>
                                <div>
                                    <p class="text-lg font-semibold text-gray-900 dark:text-white">
                                        <?php echo e($patient['patient_name']); ?>

                                    </p>
                                    <p class="text-base text-gray-500 dark:text-gray-400 mt-1">
                                        <?php echo e($patient['time']); ?>

                                    </p>
                                </div>
                            </div>

                            <div class="flex flex-wrap items-center gap-3">
                                <form action="<?php echo e(route('queues.update-queue', $patient['id'])); ?>" 
                                      method="POST" 
                                      class="flex items-center gap-2">
                                    <?php echo csrf_field(); ?>
                                    <input type="number" 
                                           name="queue_number" 
                                           value="<?php echo e($patient['queue_number']); ?>" 
                                           min="1"
                                           class="h-11 w-20 px-3 text-base text-center font-semibold border border-gray-200 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400">
                                    <button type="submit"
                                            class="h-11 px-5 text-base font-medium bg-white dark:bg-gray-800 text-gray-900 dark:text-white border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                                        <?php echo e(__('file.update')); ?>

                                    </button>
                                </form>

                                <form action="<?php echo e(route('queues.complete', $patient['id'])); ?>" 
                                      method="POST" 
                                      class="inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit"
                                            onclick="return confirm('<?php echo e(__('file.confirm_mark_completed')); ?>')"
                                            class="h-11 px-5 text-base font-medium bg-gray-900 dark:bg-gray-700 text-white rounded-lg hover:bg-gray-800 dark:hover:bg-gray-600 transition-colors">
                                        <?php echo e(__('file.complete')); ?>

                                    </button>
                                </form>

                                <a href="<?php echo e(route('appointments.show', $patient['id'])); ?>"
                                   class="h-11 px-4 text-base font-medium text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white flex items-center transition-colors">
                                    <?php echo e(__('file.view_details')); ?> →
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Program Files\xampp\htdocs\test\appointmentsystem\docappointment\resources\views/queues/daily-overview.blade.php ENDPATH**/ ?>