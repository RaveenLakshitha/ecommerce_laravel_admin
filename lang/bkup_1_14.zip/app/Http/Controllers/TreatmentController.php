<?php

namespace App\Http\Controllers;

use App\Models\Treatment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class TreatmentController extends Controller
{
    /**
     * Display a listing of treatments
     */
    public function index(Request $request)
    {
        $treatments = Treatment::query()
            ->when($request->search, function ($query, $search) {
                $query->where('name', 'like', "%{$search}%")
                      ->orWhere('code', 'like', "%{$search}%");
            })
            ->when($request->status === 'active', fn($q) => $q->where('active', true))
            ->when($request->status === 'inactive', fn($q) => $q->where('active', false))
            ->orderBy('name')
            ->paginate(15)
            ->withQueryString();

        return view('treatments.index', compact('treatments'));
    }

    /**
     * Show the form for creating a new treatment
     */
    public function create()
    {
        return view('treatments.create');
    }

    /**
     * Store a newly created treatment
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name'   => 'required|string|max:255',
            'code'   => 'nullable|string|max:50|unique:treatments,code',
            'price'  => 'required|numeric|min:0',
            'active' => 'boolean',
        ]);

        Treatment::create([
            'name'   => $validated['name'],
            'code'   => $validated['code'] ?? null,
            'price'  => $validated['price'],
            'active' => $request->boolean('active', true),
        ]);

        return redirect()
            ->route('treatments.index')
            ->with('success', 'Treatment created successfully.');
    }

    /**
     * Show the form for editing the specified treatment
     */
    public function edit(Treatment $treatment)
    {
        return view('treatments.edit', compact('treatment'));
    }

    /**
     * Update the specified treatment
     */
    public function update(Request $request, Treatment $treatment)
    {
        $validated = $request->validate([
            'name'   => 'required|string|max:255',
            'code'   => [
                'nullable',
                'string',
                'max:50',
                Rule::unique('treatments', 'code')->ignore($treatment->id),
            ],
            'price'  => 'required|numeric|min:0',
            'active' => 'boolean',
        ]);

        $treatment->update([
            'name'   => $validated['name'],
            'code'   => $validated['code'] ?? null,
            'price'  => $validated['price'],
            'active' => $request->boolean('active', $treatment->active),
        ]);

        return redirect()
            ->route('treatments.index')
            ->with('success', 'Treatment updated successfully.');
    }

    /**
     * Remove the specified treatment (soft delete or force if needed)
     */
    public function destroy(Treatment $treatment)
    {
        // Optional: Check if it's used in appointments before delete
        if ($treatment->appointments()->exists()) {
            return back()->with('error', 'Cannot delete treatment in use by appointments.');
        }

        $treatment->delete();

        return redirect()
            ->route('treatments.index')
            ->with('success', 'Treatment deleted successfully.');
    }

    /**
     * Toggle active/inactive status (AJAX friendly)
     */
    public function toggleActive(Request $request, Treatment $treatment)
    {
        $treatment->update([
            'active' => !$treatment->active,
        ]);

        return response()->json([
            'success' => true,
            'active'  => $treatment->active,
            'message' => $treatment->active ? 'Treatment activated' : 'Treatment deactivated',
        ]);
    }

    /**
     * Get treatment details (for AJAX when selecting in appointment form)
     */
    public function getTreatment(Treatment $treatment)
    {
        return response()->json([
            'id'     => $treatment->id,
            'name'   => $treatment->name,
            'code'   => $treatment->code ?? null,
            'price'  => number_format($treatment->price, 2),
            'active' => $treatment->active,
        ]);
    }
}