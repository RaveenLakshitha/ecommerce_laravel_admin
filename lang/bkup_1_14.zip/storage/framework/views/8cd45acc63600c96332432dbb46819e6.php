

<?php $__env->startSection('title', __('file.create_new_role')); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8 max-w-5xl">
    <!-- Breadcrumb & Header -->
    <div class="mb-5">
        <div class="flex items-center text-sm text-gray-600 dark:text-gray-400 mb-1">
            <a href="<?php echo e(route('admin.roles.index')); ?>" class="text-gray-600 dark:text-gray-400">
                <?php echo e(__('file.roles')); ?>

            </a>
            <svg class="w-4 h-4 mx-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
            </svg>
            <span><?php echo e(__('file.create_new_role')); ?></span>
        </div>
        <h1 class="text-2xl font-bold text-gray-900 dark:text-white">
            <?php echo e(__('file.create_new_role')); ?>

        </h1>
        <p class="text-sm text-gray-600 dark:text-gray-400">
            <?php echo e(__('file.set_up_role')); ?>

        </p>
    </div>

    <form action="<?php echo e(route('admin.roles.store')); ?>" method="POST" class="space-y-5">
        <?php echo csrf_field(); ?>

        <!-- Role Details Card -->
        <div class="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
            <div class="px-5 py-3 border-b border-gray-200 dark:border-gray-700">
                <h2 class="text-base font-semibold text-gray-900 dark:text-white">
                    <?php echo e(__('file.role_details')); ?>

                </h2>
            </div>
            <div class="p-5">
                <div>
                    <label class="block text-sm font-medium text-gray-900 dark:text-white mb-1.5">
                        <?php echo e(__('file.role_name')); ?> <span class="text-red-500">*</span>
                    </label>
                    <input type="text"
                           name="name"
                           value="<?php echo e(old('name')); ?>"
                           required
                           class="w-full px-3 py-2 bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-600 rounded-md text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500"
                           placeholder="<?php echo e(__('file.role_name_placeholder')); ?>">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1.5 text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Permissions Card -->
        <div class="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
            <div class="px-5 py-3 border-b border-gray-200 dark:border-gray-700">
                <h2 class="text-base font-semibold text-gray-900 dark:text-white">
                    <?php echo e(__('file.permissions')); ?>

                </h2>
            </div>
            <div class="p-5">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="border border-gray-200 dark:border-gray-700 rounded-md overflow-hidden">
                            <div class="px-4 py-2.5 bg-gray-50 dark:bg-gray-900/30">
                                <h3 class="text-sm font-medium text-gray-800 dark:text-gray-200 capitalize">
                                    <?php echo e(Str::title($group)); ?>

                                </h3>
                            </div>
                            <div class="p-3 space-y-1">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="flex items-center py-1.5 px-3 cursor-pointer">
                                        <input type="checkbox"
                                               name="permissions[]"
                                               value="<?php echo e($permission->name); ?>"
                                               <?php echo e(in_array($permission->name, old('permissions', [])) ? 'checked' : ''); ?>

                                               class="h-4 w-4 rounded border-gray-300 dark:border-gray-600 text-green-600 focus:ring-green-500">
                                        <span class="ml-3 text-sm text-gray-700 dark:text-gray-300">
                                            <?php echo e($permission->name); ?>

                                        </span>
                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['permissions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-3 text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="flex items-center justify-between pt-3">
            <a href="<?php echo e(route('admin.roles.index')); ?>"
               class="text-sm text-gray-600 dark:text-gray-400">
                <?php echo e(__('file.back_to_roles')); ?>

            </a>
            <div class="flex space-x-3">
                <a href="<?php echo e(route('admin.roles.index')); ?>"
                   class="px-5 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md">
                    <?php echo e(__('file.cancel')); ?>

                </a>
                <button type="submit"
                        class="px-6 py-2 text-sm font-medium text-white bg-green-600 rounded-md">
                    <?php echo e(__('file.create_role')); ?>

                </button>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Program Files\xampp\htdocs\test\appointmentsystem\docappointment\resources\views/admin/roles/create.blade.php ENDPATH**/ ?>