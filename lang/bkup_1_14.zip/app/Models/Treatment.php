<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;


class Treatment extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'code',       
        'price',
        'active',
    ];

    protected $casts = [
        'price'  => 'decimal:2',
        'active' => 'boolean',
    ];

    public function appointments()
    {
        return $this->belongsToMany(Appointment::class, 'appointment_treatment')
            ->withPivot(['quantity', 'price_at_time', 'notes'])
            ->withTimestamps();
    }
}