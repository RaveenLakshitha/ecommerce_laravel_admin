

<?php $__env->startSection('title', __('file.create_appointment_request')); ?>

<?php $__env->startSection('content'); ?>
<div class="px-4 sm:px-6 lg:px-4 pb-4 sm:py-12 pt-20">
    <div class="mb-8">
        <div class="flex items-center text-sm text-gray-500 dark:text-gray-400 mb-3">
            <a href="<?php echo e(route('appointment_requests.index')); ?>" class="hover:text-gray-700 dark:hover:text-gray-300 transition-colors">
                <?php echo e(__('file.appointment_requests')); ?>

            </a>
            <svg class="w-4 h-4 mx-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
            </svg>
            <span class="text-gray-900 dark:text-white"><?php echo e(__('file.create')); ?></span>
        </div>
        <h1 class="text-3xl font-semibold text-gray-900 dark:text-white">
            <?php echo e(__('file.create_new_appointment_request')); ?>

        </h1>
        <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
            <?php echo e(__('file.create_appointment_request_description')); ?>

        </p>
    </div>

    <form method="POST" action="<?php echo e(route('appointment_requests.store')); ?>" class="space-y-8">
        <?php echo csrf_field(); ?>

        <div class="bg-white dark:bg-transparent rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
            <div class="p-6">
                <div class="space-y-8">

                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            <?php echo e(__('file.patient')); ?> <span class="text-red-500">*</span>
                        </label>
                        <select name="patient_id" required class="tom-select-patient w-full">
                            <option value=""><?php echo e(__('file.select_patient')); ?></option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($patient->id); ?>" <?php echo e(old('patient_id') == $patient->id ? 'selected' : ''); ?>>
                                    <?php echo e($patient->getFullNameAttribute()); ?> (ID: <?php echo e($patient->id); ?>)
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </select>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1.5 text-xs text-red-600 dark:text-red-400"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <div class="pt-6 border-t border-gray-200 dark:border-gray-700">
                        <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-6">
                            <?php echo e(__('file.request_details')); ?>

                        </h3>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                    <?php echo e(__('file.doctor_selection')); ?> <span class="text-red-500">*</span>
                                </label>
                                <select name="doctor_selection_mode" required id="doctor-selection-mode"
                                        class="w-full px-3 py-2.5 text-sm border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-gray-900 dark:focus:ring-gray-500 focus:border-transparent transition-all">
                                    <option value=""><?php echo e(__('file.select_option')); ?></option>
                                    <option value="specific" <?php echo e(old('doctor_selection_mode') == 'specific' ? 'selected' : ''); ?>>
                                        <?php echo e(__('file.specific_doctor')); ?>

                                    </option>
                                    <option value="primary_provider" <?php echo e(old('doctor_selection_mode') == 'primary_provider' ? 'selected' : ''); ?>>
                                        <?php echo e(__('file.primary_care_provider')); ?>

                                    </option>
                                </select>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['doctor_selection_mode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1.5 text-xs text-red-600 dark:text-red-400"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                    <?php echo e(__('file.specialization')); ?> <span class="text-red-500">*</span>
                                </label>
                                <select name="specialization_id" required id="specialization-select"
                                        class="w-full px-3 py-2.5 text-sm border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-gray-900 dark:focus:ring-gray-500 focus:border-transparent transition-all">
                                    <option value=""><?php echo e(__('file.select_specialization')); ?></option>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $specializations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($specialization->id); ?>" <?php echo e(old('specialization_id') == $specialization->id ? 'selected' : ''); ?>>
                                            <?php echo e($specialization->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </select>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['specialization_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1.5 text-xs text-red-600 dark:text-red-400"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </div>

                        <div id="specific-doctor-field" class="mt-6 <?php echo e(old('doctor_selection_mode') == 'specific' ? '' : 'hidden'); ?>">
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                <?php echo e(__('file.select_doctor')); ?> <span class="text-red-500 doctor-required">*</span>
                            </label>

                            <select name="doctor_id" id="doctor-select" class="tom-select-doctor w-full">
                                <option value=""><?php echo e(__('file.select_specialization_first')); ?></option>
                            </select>

                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['doctor_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="mt-1.5 text-xs text-red-600 dark:text-red-400"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                    <?php echo e(__('file.requested_date')); ?> <span class="text-red-500">*</span>
                                </label>
                                <input type="date" name="requested_date" value="<?php echo e(old('requested_date')); ?>" required min="<?php echo e(now()->format('Y-m-d')); ?>"
                                       class="w-full px-3 py-2.5 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-gray-900 dark:focus:ring-gray-500 focus:border-transparent dark:bg-transparent dark:text-white transition-shadow">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                    <?php echo e(__('file.preferred_start_time')); ?> <span class="text-red-500">*</span>
                                </label>
                                <input type="time" name="requested_start_time" value="<?php echo e(old('requested_start_time')); ?>" required
                                       class="w-full px-3 py-2.5 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-gray-900 dark:focus:ring-gray-500 focus:border-transparent dark:bg-transparent dark:text-white transition-shadow">
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                    <?php echo e(__('file.preferred_time_range_start')); ?>

                                </label>
                                <input type="time" name="preferred_time_range_start" value="<?php echo e(old('preferred_time_range_start')); ?>"
                                       class="w-full px-3 py-2.5 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-gray-900 dark:focus:ring-gray-500 focus:border-transparent dark:bg-transparent dark:text-white transition-shadow">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                    <?php echo e(__('file.preferred_time_range_end')); ?>

                                </label>
                                <input type="time" name="preferred_time_range_end" value="<?php echo e(old('preferred_time_range_end')); ?>"
                                       class="w-full px-3 py-2.5 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-gray-900 dark:focus:ring-gray-500 focus:border-transparent dark:bg-transparent dark:text-white transition-shadow">
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                    <?php echo e(__('file.duration_minutes')); ?> <span class="text-red-500">*</span>
                                </label>
                                <select name="duration_minutes" required
                                        class="w-full px-3 py-2.5 text-sm border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-gray-900 dark:focus:ring-gray-500 focus:border-transparent transition-all">
                                    <option value="15" <?php echo e(old('duration_minutes', 30) == 15 ? 'selected' : ''); ?>>15 <?php echo e(__('file.minutes')); ?></option>
                                    <option value="30" <?php echo e(old('duration_minutes', 30) == 30 ? 'selected' : ''); ?>>30 <?php echo e(__('file.minutes')); ?></option>
                                    <option value="45" <?php echo e(old('duration_minutes', 30) == 45 ? 'selected' : ''); ?>>45 <?php echo e(__('file.minutes')); ?></option>
                                    <option value="60" <?php echo e(old('duration_minutes', 30) == 60 ? 'selected' : ''); ?>>60 <?php echo e(__('file.minutes')); ?></option>
                                    <option value="90" <?php echo e(old('duration_minutes', 30) == 90 ? 'selected' : ''); ?>>90 <?php echo e(__('file.minutes')); ?></option>
                                </select>
                            </div>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                <?php echo e(__('file.reason_for_visit')); ?> <span class="text-red-500">*</span>
                            </label>
                            <textarea name="reason_for_visit" rows="4" required placeholder="<?php echo e(__('file.reason_for_visit_placeholder')); ?>"
                                      class="w-full px-3 py-2.5 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-gray-900 dark:focus:ring-gray-500 focus:border-transparent dark:bg-transparent dark:text-white transition-shadow resize-none"><?php echo e(old('reason_for_visit')); ?></textarea>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                <?php echo e(__('file.additional_notes')); ?>

                            </label>
                            <textarea name="notes" rows="4" placeholder="<?php echo e(__('file.additional_notes_placeholder')); ?>"
                                      class="w-full px-3 py-2.5 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-gray-900 dark:focus:ring-gray-500 focus:border-transparent dark:bg-transparent dark:text-white transition-shadow resize-none"><?php echo e(old('notes')); ?></textarea>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="flex flex-col sm:flex-row gap-3 pt-2">
            <button type="submit"
                    class="inline-flex items-center justify-center px-6 py-3 bg-gray-900 dark:bg-white text-white dark:text-gray-900 text-sm font-medium rounded-lg hover:bg-gray-800 dark:hover:bg-gray-200 transition-colors duration-200 shadow-sm">
                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                </svg>
                <?php echo e(__('file.create_request')); ?>

            </button>
            <a href="<?php echo e(route('appointment_requests.index')); ?>"
               class="inline-flex items-center justify-center px-6 py-3 bg-gray-100 dark:bg-transparent border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 text-sm font-medium rounded-lg hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors duration-200">
                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                </svg>
                <?php echo e(__('file.cancel')); ?>

            </a>
        </div>
    </form>
</div>

<link href="https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/css/tom-select.css" rel="stylesheet">
<style>
    .dark .ts-wrapper .ts-control { background-color: transparent !important; border-color: rgb(75 85 99) !important; color: white !important; }
    .dark .ts-wrapper .ts-control input { color: white !important; }
    .dark .ts-wrapper .ts-dropdown { background-color: rgb(31 41 55) !important; border-color: rgb(75 85 99) !important; }
    .dark .ts-wrapper .ts-dropdown .option { color: rgb(229 231 235) !important; }
    .dark .ts-wrapper .ts-dropdown .option:hover,
    .dark .ts-wrapper .ts-dropdown .option.active { background-color: rgb(55 65 81) !important; color: white !important; }
</style>

<script src="https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/js/tom-select.complete.min.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function () {
    new TomSelect('.tom-select-patient', {
        maxItems: 1,
        placeholder: '<?php echo e(__('file.search_patient')); ?>',
        render: {
            option: function(data, escape) { return `<div class="py-2 px-3">${escape(data.text)}</div>`; },
            item: function(data, escape) { return `<div>${escape(data.text)}</div>`; }
        }
    });

    const doctorModeSelect = document.getElementById('doctor-selection-mode');
    const specificDoctorField = document.getElementById('specific-doctor-field');
    const specializationSelect = document.getElementById('specialization-select');
    const doctorSelectEl = document.getElementById('doctor-select');

    let doctorTomSelect = null;

    function initializeDoctorTomSelect() {
        if (doctorTomSelect) return;

        doctorTomSelect = new TomSelect('#doctor-select', {
            maxItems: 1,
            placeholder: '<?php echo e(__('file.select_specialization_first')); ?>',
            valueField: 'value',
            labelField: 'text',
            searchField: ['text'],
            render: {
                option: function(data, escape) {
                    return `<div class="py-2 px-3">${escape(data.text)}</div>`;
                },
                item: function(data, escape) {
                    return `<div>${escape(data.text)}</div>`;
                }
            }
        });
    }

    function setDoctorPlaceholder(text) {
        if (doctorTomSelect) {
            const control = doctorTomSelect.control;
            const input = control.querySelector('input[placeholder]') || 
                          control.querySelector('.ts-control > div');
            if (input) {
                input.setAttribute('placeholder', text);
            }
        }
    }

    function loadDoctors(specializationId) {
        if (!doctorTomSelect) initializeDoctorTomSelect();

        doctorTomSelect.clear();
        doctorTomSelect.clearOptions();

        if (!specializationId) {
            setDoctorPlaceholder('<?php echo e(__('file.select_specialization_first')); ?>');
            return;
        }

        setDoctorPlaceholder('<?php echo e(__('file.loading_doctors')); ?>...');

        // Use the named route with Laravel's route() helper
        fetch(`<?php echo e(route('doctors.by_specialization', ':specialization_id')); ?>`.replace(':specialization_id', specializationId))
            .then(response => {
                if (!response.ok) throw new Error('Network error');
                return response.json();
            })
            .then(data => {
                doctorTomSelect.addOptions(data);
                setDoctorPlaceholder('<?php echo e(__('file.select_doctor')); ?>');

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(old('doctor_id')): ?>
                    const oldDoctorId = '<?php echo e(old('doctor_id')); ?>';
                    if (data.some(opt => opt.value == oldDoctorId)) {
                        doctorTomSelect.addItem(oldDoctorId);
                    }
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            })
            .catch(() => {
                setDoctorPlaceholder('<?php echo e(__('file.no_doctors_found')); ?>');
            });
    }

    function toggleDoctorField() {
        if (doctorModeSelect.value === 'specific') {
            specificDoctorField.classList.remove('hidden');
            doctorSelectEl.setAttribute('required', 'required');
            initializeDoctorTomSelect();

            const specId = specializationSelect.value;
            if (specId) {
                loadDoctors(specId);
            } else {
                setDoctorPlaceholder('<?php echo e(__('file.select_specialization_first')); ?>');
            }
        } else {
            specificDoctorField.classList.add('hidden');
            doctorSelectEl.removeAttribute('required');
            if (doctorTomSelect) {
                doctorTomSelect.clear();
                doctorTomSelect.clearOptions();
                setDoctorPlaceholder('<?php echo e(__('file.select_specialization_first')); ?>');
            }
        }
    }

    specializationSelect.addEventListener('change', function() {
        if (doctorModeSelect.value === 'specific') {
            loadDoctors(this.value);
        }
    });

    doctorModeSelect.addEventListener('change', toggleDoctorField);

    toggleDoctorField();

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(old('specialization_id') && old('doctor_selection_mode') == 'specific'): ?>
        loadDoctors('<?php echo e(old('specialization_id')); ?>');
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Program Files\xampp\htdocs\test\appointmentsystem\docappointment\resources\views/appointment-requests/create.blade.php ENDPATH**/ ?>