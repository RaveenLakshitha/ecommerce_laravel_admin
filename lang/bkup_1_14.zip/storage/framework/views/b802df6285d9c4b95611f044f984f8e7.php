

<?php $__env->startSection('title', __('file.schedule_appointment')); ?>

<?php $__env->startSection('content'); ?>
<div class="px-4 sm:px-6 lg:px-4 pb-4 sm:py-12 pt-20">
    <div class="mb-8">
        <div class="flex items-center text-sm text-gray-500 dark:text-gray-400 mb-3">
            <a href="<?php echo e(route('appointments.index')); ?>" class="hover:text-gray-700 dark:hover:text-gray-300 transition-colors">
                <?php echo e(__('file.appointments')); ?>

            </a>
            <svg class="w-4 h-4 mx-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
            </svg>
            <span class="text-gray-900 dark:text-white"><?php echo e(__('file.schedule_appointment')); ?></span>
        </div>
        <h1 class="text-3xl font-semibold text-gray-900 dark:text-white"><?php echo e(__('file.schedule_new_appointment')); ?></h1>

    </div>

    <form method="POST" action="<?php echo e(route('appointments.store')); ?>" class="space-y-8">
        <?php echo csrf_field(); ?>

        <div class="bg-white dark:bg-transparent rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden p-6">
            <div class="space-y-6">

                <!-- Patient -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            <?php echo e(__('file.patient')); ?> <span class="text-red-500">*</span>
                        </label>
                        <select name="patient_id" required 
                                class="w-full px-2 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-gray-900 dark:focus:ring-gray-500 focus:border-transparent dark:bg-transparent dark:text-white">
                            <option value=""><?php echo e(__('file.select_patient')); ?></option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($patient->id); ?>" <?php echo e(old('patient_id') == $patient->id ? 'selected' : ''); ?>>
                                    <?php echo e($patient->getFullNameAttribute()); ?> (MRN: <?php echo e($patient->medical_record_number ?? 'N/A'); ?>)
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </select>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1.5 text-xs text-red-600 dark:text-red-400"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <!-- Appointment Type -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            <?php echo e(__('file.appointment_type')); ?> <span class="text-red-500">*</span>
                        </label>
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <label class="flex items-center p-4 border rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700/50 transition
                                <?php echo e(old('appointment_type', \App\Models\Appointment::TYPE_SPECIFIC) == \App\Models\Appointment::TYPE_SPECIFIC ? 'border-gray-900 bg-gray-100 dark:border-gray-400 dark:bg-gray-700/70' : 'border-gray-300 dark:border-gray-600'); ?>">
                                <input type="radio" name="appointment_type" value="<?php echo e(\App\Models\Appointment::TYPE_SPECIFIC); ?>"
                                       class="text-gray-900 focus:ring-gray-900" 
                                       <?php echo e(old('appointment_type', \App\Models\Appointment::TYPE_SPECIFIC) == \App\Models\Appointment::TYPE_SPECIFIC ? 'checked' : ''); ?>>
                                <span class="ml-3 text-sm font-medium text-gray-900 dark:text-white"><?php echo e(__('file.specific_doctor')); ?></span>
                            </label>

                            <label class="flex items-center p-4 border rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700/50 transition
                                <?php echo e(old('appointment_type') == \App\Models\Appointment::TYPE_ANY ? 'border-gray-900 bg-gray-100 dark:border-gray-400 dark:bg-gray-700/70' : 'border-gray-300 dark:border-gray-600'); ?>">
                                <input type="radio" name="appointment_type" value="<?php echo e(\App\Models\Appointment::TYPE_ANY); ?>"
                                       class="text-gray-900 focus:ring-gray-900" 
                                       <?php echo e(old('appointment_type') == \App\Models\Appointment::TYPE_ANY ? 'checked' : ''); ?>>
                                <span class="ml-3 text-sm font-medium text-gray-900 dark:text-white"><?php echo e(__('file.any_doctor')); ?></span>
                            </label>
                        </div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['appointment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1.5 text-xs text-red-600 dark:text-red-400"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>

                <!-- Specialization (for Any Doctor) -->
                <div id="specialization-group" class="hidden">
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        <?php echo e(__('file.specialization')); ?> <span id="spec-required" class="text-red-500 hidden">*</span>
                    </label>
                    <select name="specialization_id" id="specialization_id"
                            class="w-full px-2 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-gray-900 dark:focus:ring-gray-500 focus:border-transparent dark:bg-transparent dark:text-white">
                        <option value=""><?php echo e(__('file.select_specialization')); ?></option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $specializations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($spec->id); ?>" <?php echo e(old('specialization_id') == $spec->id ? 'selected' : ''); ?>>
                                <?php echo e($spec->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </select>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['specialization_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1.5 text-xs text-red-600 dark:text-red-400"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <!-- Specific Doctor -->
                <div id="doctor-group" class="hidden">
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        <?php echo e(__('file.doctor')); ?> <span id="doctor-required" class="text-red-500 hidden">*</span>
                    </label>
                    <select name="doctor_id" id="doctor_id"
                            class="w-full px-2 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-gray-900 dark:focus:ring-gray-500 focus:border-transparent dark:bg-transparent dark:text-white">
                        <option value=""><?php echo e(__('file.select_doctor')); ?></option>
                    </select>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['doctor_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1.5 text-xs text-red-600 dark:text-red-400"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <!-- Reason for Visit -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        <?php echo e(__('file.reason_for_visit')); ?> <span class="text-red-500">*</span>
                    </label>
                    <textarea name="reason_for_visit" rows="5" required
                              class="w-full px-2 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-gray-900 dark:focus:ring-gray-500 focus:border-transparent dark:bg-transparent dark:text-white resize-none"
                              placeholder="<?php echo e(__('file.describe_reason')); ?>"><?php echo e(old('reason_for_visit')); ?></textarea>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['reason_for_visit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1.5 text-xs text-red-600 dark:text-red-400"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <!-- Patient Notes -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        <?php echo e(__('file.patient_notes')); ?>

                    </label>
                    <textarea name="patient_notes" rows="4"
                              class="w-full px-2 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-gray-900 dark:focus:ring-gray-500 focus:border-transparent dark:bg-transparent dark:text-white resize-none"
                              placeholder="<?php echo e(__('file.optional_notes')); ?>"><?php echo e(old('patient_notes')); ?></textarea>
                </div>

            </div>
        </div>

        <div class="flex flex-col sm:flex-row gap-3 pt-2">
            <button type="submit" 
                    class="inline-flex items-center justify-center px-6 py-3 bg-gray-900 border border-gray-300 dark:border-gray-600 dark:bg-white dark:text-gray-900 text-white text-sm font-medium rounded-lg hover:bg-gray-800 dark:hover:bg-gray-300 transition-colors duration-200 shadow-sm">
                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                </svg>
                <?php echo e(__('file.create_appointment_request')); ?>

            </button>

            <a href="<?php echo e(route('appointments.index')); ?>" 
               class="inline-flex items-center justify-center px-6 py-3 bg-gray-100 dark:bg-transparent border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 text-sm font-medium rounded-lg hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors duration-200">
                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                </svg>
                <?php echo e(__('file.cancel')); ?>

            </a>
        </div>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const typeRadios          = document.querySelectorAll('input[name="appointment_type"]');
    const specializationGroup = document.getElementById('specialization-group');
    const doctorGroup         = document.getElementById('doctor-group');
    const specRequiredMark    = document.getElementById('spec-required');
    const doctorRequiredMark  = document.getElementById('doctor-required');
    const specializationSelect = document.getElementById('specialization_id');
    const doctorSelect        = document.getElementById('doctor_id');

    function getCurrentType() {
        return document.querySelector('input[name="appointment_type"]:checked')?.value || '<?php echo e(\App\Models\Appointment::TYPE_SPECIFIC); ?>';
    }

    function updateFormVisibility() {
        const type = getCurrentType();
        const isSpecific = type === '<?php echo e(\App\Models\Appointment::TYPE_SPECIFIC); ?>';
        const isAny      = type === '<?php echo e(\App\Models\Appointment::TYPE_ANY); ?>';

        specializationGroup.classList.toggle('hidden', !isAny);
        doctorGroup.classList.toggle('hidden', !isSpecific);

        specRequiredMark.classList.toggle('hidden', !isAny);
        doctorRequiredMark.classList.toggle('hidden', !isSpecific);

        specializationSelect.required = isAny;
        doctorSelect.required = isSpecific;

        // Reset doctor dropdown when switching to specific
        if (isSpecific) {
            loadAllDoctors();
            specializationSelect.value = '';
        }
    }

    function loadAllDoctors() {
        fetch('<?php echo e(route("appointments.filters", ["column" => "doctor"])); ?>')
            .then(r => r.json())
            .then(data => {
                doctorSelect.innerHTML = '<option value=""><?php echo e(__("file.select_doctor")); ?></option>';
                Object.entries(data).forEach(([id, name]) => {
                    const opt = new Option(name, id);
                    if ('<?php echo e(old('doctor_id')); ?>' == id) opt.selected = true;
                    doctorSelect.add(opt);
                });
            });
    }

    typeRadios.forEach(r => r.addEventListener('change', updateFormVisibility));
    updateFormVisibility(); // initial state
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Program Files\xampp\htdocs\test\appointmentsystem\docappointment\resources\views/appointments/create.blade.php ENDPATH**/ ?>