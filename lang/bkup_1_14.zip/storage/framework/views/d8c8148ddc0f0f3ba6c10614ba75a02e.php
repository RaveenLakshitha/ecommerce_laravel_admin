<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    <div class="flex justify-between items-center mb-8">
        <h1 class="text-2xl font-bold text-gray-900 dark:text-white">
            Daily Queue - <?php echo e($date->format('D, M d, Y')); ?>

        </h1>

        <div class="flex items-center gap-4">
            <input type="date"
                   wire:model.live="date"
                   class="px-4 py-2 border rounded-lg dark:bg-gray-700 dark:text-white">

            <!-- Optional: today button -->
            <button wire:click="$set('date', '<?php echo e(today()->format('Y-m-d')); ?>')"
                    type="button"
                    class="px-4 py-2 bg-gray-600 text-white rounded hover:bg-gray-700">
                Today
            </button>
        </div>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($queues->isEmpty()): ?>
        <div class="bg-white dark:bg-gray-800 rounded-lg p-8 text-center text-gray-500 dark:text-gray-400">
            No approved appointments queued for this date.
        </div>
    <?php else: ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $queues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white dark:bg-gray-800 rounded-lg shadow mb-8 overflow-hidden">
                <div class="bg-indigo-600 text-white px-6 py-4">
                    <div class="flex justify-between items-center">
                        <h2 class="text-xl font-semibold uppercase">
                            <?php echo e($session['session_key']); ?>

                            <span class="text-indigo-200 ml-2">(<?php echo e($session['doctor_name']); ?>)</span>
                        </h2>
                        <span class="bg-indigo-800 px-3 py-1 rounded-full text-sm">
                            <?php echo e($session['patients']->count()); ?> patients
                        </span>
                    </div>
                </div>

                <div class="divide-y divide-gray-200 dark:divide-gray-700">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $session['patients']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="px-6 py-4 flex flex-col sm:flex-row sm:items-center justify-between hover:bg-gray-50 dark:hover:bg-gray-700 transition gap-4">
                            <div class="flex items-center gap-6 flex-1">
                                <div class="text-2xl font-bold text-indigo-600 w-16 text-center">
                                    #<?php echo e($patient['queue_number']); ?>

                                </div>
                                <div>
                                    <p class="font-medium text-gray-900 dark:text-white">
                                        <?php echo e($patient['patient_name']); ?>

                                    </p>
                                    <p class="text-sm text-gray-500 dark:text-gray-400">
                                        <?php echo e($patient['time']); ?>

                                    </p>
                                </div>
                            </div>

                            <div class="flex items-center gap-4 flex-wrap">
                                <!-- Edit queue number -->
                                <div class="flex items-center gap-2">
                                    <input type="number"
                                           min="1"
                                           wire:model.live.debounce.500ms="tempQueue.<?php echo e($patient['id']); ?>"
                                           class="w-20 px-2 py-1 border rounded dark:bg-gray-700 dark:text-white text-center"
                                           placeholder="<?php echo e($patient['queue_number']); ?>">

                                    <button wire:click="updateQueueNumber(<?php echo e($patient['id']); ?>, $wire.tempQueue.<?php echo e($patient['id']); ?>)"
                                            class="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700">
                                        Update
                                    </button>
                                </div>

                                <!-- Mark as Completed -->
                                <button wire:click="markCompleted(<?php echo e($patient['id']); ?>)"
                                        wire:confirm="Mark this appointment as completed? Queue will be renumbered."
                                        class="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 text-sm font-medium">
                                    Complete
                                </button>

                                <a href="<?php echo e(route('appointments.show', $patient['id'])); ?>"
                                   class="text-indigo-600 hover:text-indigo-800 dark:text-indigo-400 dark:hover:text-indigo-300 text-sm">
                                    View →
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div><?php /**PATH E:\Program Files\xampp\htdocs\test\appointmentsystem\docappointment\resources\views/livewire/daily-queue.blade.php ENDPATH**/ ?>