<?php

namespace App\Http\Controllers;

use App\Models\Patient;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Barryvdh\DomPDF\Facade\Pdf;
use App\Exports\PatientsExport;
use DB;

class PatientController extends Controller
{
    public function index(Request $request)
    {
        $patients = Patient::active()
            ->orderBy('first_name')
            ->paginate(10)
            ->withQueryString();

        return view('patients.index', compact('patients'));
    }

    public function datatable(Request $request)
    {
        $draw = $request->input('draw');
        $start = $request->input('start', 0);
        $length = $request->input('length', 10);
        $orderColumnIndex = $request->input('order.0.column');
        $orderDir = $request->input('order.0.dir', 'asc');
        $search = trim($request->input('search.value', ''));
        $ageFrom = $request->age_from;
        $ageTo   = $request->age_to;

        $gender = $request->gender;
        $status = $request->status;
        $from   = $request->from;
        $to     = $request->to;

        $query = Patient::query()
            ->leftJoin('appointments', fn($join) => $join
                ->on('appointments.patient_id', '=', 'patients.id')
                ->whereRaw('appointments.id = (
                    SELECT MAX(a2.id)
                    FROM appointments a2
                    WHERE a2.patient_id = patients.id
                    AND a2.deleted_at IS NULL
                )')
            )
            ->select(
                'patients.*',
                DB::raw('appointments.scheduled_start as last_appointment_date')
            )
            ->when($search !== '', fn($q) => $q
                ->whereRaw("CONCAT(first_name, ' ', COALESCE(middle_name,''), ' ', last_name) LIKE ?", ["%{$search}%"])
                ->orWhere('medical_record_number', 'like', "%{$search}%")
            )
            ->when($gender, fn($q) => $q->where('patients.gender', $gender))
            ->when($status !== null && $status !== '', fn($q) => $q->where('patients.is_active', $status))
            ->when($ageFrom || $ageTo, fn($q) => $q->whereRaw("TIMESTAMPDIFF(YEAR, date_of_birth, CURDATE()) BETWEEN ? AND ?", [
                $ageFrom ?? 0,
                $ageTo ?? 200
            ]))
            ->when($from || $to, fn($q) => $q->havingRaw(
                'last_appointment_date ' .
                ($from && $to ? 'BETWEEN ? AND ?' :
                 ($from ? '>= ?' :
                  ($to ? '<= ?' : ''))),
                collect([])
                    ->when($from, fn($c) => $c->push($from . ' 00:00:00'))
                    ->when($to, fn($c) => $c->push($to . ' 23:59:59'))
                    ->toArray()
            ))
            ->active();

        $totalRecords = Patient::active()->count();
        $filteredRecords = (clone $query)->count();

        // Ordering
        if ($orderColumnIndex == 1) {
            $query->orderBy('medical_record_number', $orderDir);
        } elseif ($orderColumnIndex == 2) {
            $query->orderBy('first_name', $orderDir)->orderBy('last_name', $orderDir);
        } elseif ($orderColumnIndex == 3) {
            $query->orderBy('date_of_birth', $orderDir);
        } elseif ($orderColumnIndex == 4) {
            $query->orderByRaw("FIELD(LOWER(patients.gender), 'male', 'female', 'other', NULL) {$orderDir}");
        } elseif ($orderColumnIndex == 5) {
            // Order by last appointment date (nulls last)
            $query->orderBy('last_appointment_date', $orderDir);
        } elseif ($orderColumnIndex == 6) {
            $query->orderBy('is_active', $orderDir);
        } else {
            $query->orderBy('created_at', 'desc');
        }

        $patients = $query->offset($start)->limit($length)->get();
        $now = now();

        $data = $patients->map(function ($p) use ($now) {
            $lastVisit = $p->last_appointment_date
                ? \Carbon\Carbon::parse($p->last_appointment_date)->format('M d, Y')
                : null;

            $age = $p->date_of_birth ? $p->date_of_birth->diffInYears($now) : null;

            $genderBadge = match(strtolower($p->gender ?? '')) {
                'male'   => '<span class="inline-flex items-center px-2.5 py-0.5 rounded text-xs font-medium bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300">Male</span>',
                'female' => '<span class="inline-flex items-center px-2.5 py-0.5 rounded text-xs font-medium bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300">Female</span>',
                default  => '<span class="inline-flex items-center px-2.5 py-0.5 rounded text-xs font-medium bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400">Other</span>'
            };

            return [
                'id'                    => $p->id,
                'medical_record_number' => $p->medical_record_number ?? '',
                'full_name'             => $p->getFullNameAttribute(),
                'age'                   => $age !== null ? (int)$age : 0,
                'gender'                => $genderBadge,
                'last_visit'            => $lastVisit,
                'status_html'           => $p->is_active
                    ? '<span class="inline-flex items-center px-2.5 py-0.5 rounded text-xs font-medium bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300">Active</span>'
                    : '<span class="inline-flex items-center px-2.5 py-0.5 rounded text-xs font-medium bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400">Inactive</span>',
                'show_url'              => route('patients.show', $p),
                'edit_url'              => route('patients.edit', $p),
                'delete_url'            => route('patients.destroy', $p),
            ];
        });

        return response()->json([
            'draw'            => (int)$draw,
            'recordsTotal'    => $totalRecords,
            'recordsFiltered' => $filteredRecords,
            'data'            => $data->toArray(),
        ]);
    }

    public function create() { return view('patients.create'); }

    public function store(Request $request)
    {
        $request->validate([
            'first_name'             => 'required|string|max:255',
            'last_name'              => 'required|string|max:255',
            'date_of_birth'          => 'required|date',
            'gender'                 => 'required|in:male,female,other',
            'phone'                  => 'nullable|string|regex:/^\+?[0-9]{10,15}$/|unique:patients,phone',
            'email'                  => 'nullable|email|unique:patients,email',
            'middle_name'            => 'nullable|string|max:255',
            'marital_status'         => 'nullable|string',
            'address'                => 'nullable|string',
            'city'                   => 'nullable|string',
            'state'                  => 'nullable|string',
            'zip_code'               => 'nullable|string',
            'alternative_phone'      => 'nullable|string',
            'preferred_contact_method' => 'nullable|string',
            'emergency_contact_name' => 'nullable|string',
            'emergency_contact_relationship' => 'nullable|string',
            'emergency_contact_phone' => 'nullable|string',
            'emergency_contact_email' => 'nullable|email',
        ]);

        $lastPatient = Patient::orderBy('id', 'desc')->first();
        $nextNumber = $lastPatient ? $lastPatient->id + 1 : 1;
        $medicalRecordNumber = 'MRN-' . str_pad($nextNumber, 6, '0', STR_PAD_LEFT);

        Patient::create($request->only([
            'first_name',
            'middle_name',
            'last_name',
            'date_of_birth',
            'gender',
            'marital_status',
            'address',
            'city',
            'state',
            'zip_code',
            'phone',
            'alternative_phone',
            'email',
            'preferred_contact_method',
            'emergency_contact_name',
            'emergency_contact_relationship',
            'emergency_contact_phone',
            'emergency_contact_email',
        ]) + [
            'medical_record_number' => $medicalRecordNumber,
            'is_active'             => true,
            'is_deleted'            => false,
        ]);

        return redirect()->route('patients.index')->with('success', 'Patient created successfully.');
    }

    public function show(Patient $patient)
    {
        $patient->load(['appointments', 'prescriptions', 'invoices.payments']);
        return view('patients.show', compact('patient'));
    }
    
    public function edit(Patient $patient) { return view('patients.edit', compact('patient')); }

    public function update(Request $request, Patient $patient)
    {
        $request->validate([
            'first_name'             => 'required|string|max:255',
            'last_name'              => 'required|string|max:255',
            'date_of_birth'          => 'required|date',
            'gender'                 => 'required|in:male,female,other',
            'phone'                  => 'nullable|string|regex:/^\+?[0-9]{10,15}$/|unique:patients,phone,' . $patient->id,
            'email'                  => 'nullable|email|unique:patients,email,' . $patient->id,
            'middle_name'            => 'nullable|string|max:255',
            'marital_status'         => 'nullable|string',
            'address'                => 'nullable|string',
            'city'                   => 'nullable|string',
            'state'                  => 'nullable|string',
            'zip_code'               => 'nullable|string',
            'alternative_phone'      => 'nullable|string',
            'preferred_contact_method' => 'nullable|string',
            'emergency_contact_name' => 'nullable|string',
            'emergency_contact_relationship' => 'nullable|string',
            'emergency_contact_phone' => 'nullable|string',
            'emergency_contact_email' => 'nullable|email',
        ]);

        $patient->update($request->only([
            'first_name',
            'middle_name',
            'last_name',
            'date_of_birth',
            'gender',
            'marital_status',
            'address',
            'city',
            'state',
            'zip_code',
            'phone',
            'alternative_phone',
            'email',
            'preferred_contact_method',
            'emergency_contact_name',
            'emergency_contact_relationship',
            'emergency_contact_phone',
            'emergency_contact_email',
        ]));

        return redirect()->route('patients.index')->with('success', 'Patient updated successfully.');
    }

    public function destroy(Patient $patient) {
        $patient->update(['is_deleted' => true, 'is_active' => false]);
        return back()->with('success', 'Patient deleted.');
    }

    public function bulkDelete(Request $request) {
        $ids = $request->input('ids');
        if (is_string($ids)) $ids = array_filter(explode(',', $ids));

        $request->validate([
            'ids'   => 'required|array',
            'ids.*' => 'exists:patients,id',
        ]);

        Patient::whereIn('id', $ids)->update(['is_deleted' => true, 'is_active' => false]);
        return back()->with('success', 'Patients deleted.');
    }

    public function filters(Request $request)
    {
        $column = (int) $request->get('column');

        return match ($column) {
            1 => $this->uniqueValues('medical_record_number'),

            2 => $this->uniqueValues(
                raw: "TRIM(CONCAT(COALESCE(first_name,''), ' ', COALESCE(middle_name,''), ' ', COALESCE(last_name,'')))",
                alias: 'full_name'
            ),

            4 => $this->uniqueValues('gender'),

            6 => $this->uniqueValues(
                raw: "CASE WHEN is_active THEN 'Active' ELSE 'Inactive' END",
                alias: 'status_label'
            ),

            default => response()->json([]),
        };
    }

    private function uniqueValues(string $field = null, ?string $raw = null, string $alias = null)
    {
        $query = Patient::query();

        if ($raw) {
            $query->selectRaw("$raw AS `$alias`");
            $orderBy = $alias;
        } else {
            $query->select($field);
            $orderBy = $field;
        }

        return $query
            ->active()
            ->distinct()
            ->orderBy($orderBy)
            ->pluck($orderBy)
            ->filter()
            ->values()
            ->toArray();
    }
}